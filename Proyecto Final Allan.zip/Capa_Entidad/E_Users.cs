﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDAD
{
    public class E_Users
    {

        public String usuario { get; set; }

        public String clave { get; set; }
    }
}
