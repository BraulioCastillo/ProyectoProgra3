﻿namespace ProyectoFinal
{
    partial class Supermercado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Supermercado));
            this.btncancelar = new System.Windows.Forms.Button();
            this.btn_agregarsupermercado = new System.Windows.Forms.Button();
            this.btn_agregarnuevasede = new System.Windows.Forms.Button();
            this.btn_consultarsupermercado = new System.Windows.Forms.Button();
            this.btn_actualizarsupermercado = new System.Windows.Forms.Button();
            this.btn_actualizarsede = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btncancelar
            // 
            this.btncancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncancelar.BackgroundImage")));
            this.btncancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancelar.ForeColor = System.Drawing.Color.White;
            this.btncancelar.Location = new System.Drawing.Point(462, 221);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(100, 40);
            this.btncancelar.TabIndex = 6;
            this.btncancelar.Text = "Salir";
            this.btncancelar.UseVisualStyleBackColor = true;
            this.btncancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // btn_agregarsupermercado
            // 
            this.btn_agregarsupermercado.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_agregarsupermercado.BackgroundImage")));
            this.btn_agregarsupermercado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_agregarsupermercado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarsupermercado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_agregarsupermercado.Location = new System.Drawing.Point(71, 109);
            this.btn_agregarsupermercado.Name = "btn_agregarsupermercado";
            this.btn_agregarsupermercado.Size = new System.Drawing.Size(141, 40);
            this.btn_agregarsupermercado.TabIndex = 7;
            this.btn_agregarsupermercado.Text = "Agregar Supermercado";
            this.btn_agregarsupermercado.UseVisualStyleBackColor = true;
            this.btn_agregarsupermercado.Click += new System.EventHandler(this.btn_agregarsupermercado_Click);
            // 
            // btn_agregarnuevasede
            // 
            this.btn_agregarnuevasede.BackColor = System.Drawing.SystemColors.Control;
            this.btn_agregarnuevasede.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_agregarnuevasede.BackgroundImage")));
            this.btn_agregarnuevasede.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_agregarnuevasede.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarnuevasede.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_agregarnuevasede.Location = new System.Drawing.Point(218, 109);
            this.btn_agregarnuevasede.Name = "btn_agregarnuevasede";
            this.btn_agregarnuevasede.Size = new System.Drawing.Size(141, 40);
            this.btn_agregarnuevasede.TabIndex = 8;
            this.btn_agregarnuevasede.Text = "Agregar Sede";
            this.btn_agregarnuevasede.UseVisualStyleBackColor = false;
            this.btn_agregarnuevasede.Click += new System.EventHandler(this.btn_agregarnuevasede_Click);
            // 
            // btn_consultarsupermercado
            // 
            this.btn_consultarsupermercado.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_consultarsupermercado.BackgroundImage")));
            this.btn_consultarsupermercado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_consultarsupermercado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consultarsupermercado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_consultarsupermercado.Location = new System.Drawing.Point(365, 109);
            this.btn_consultarsupermercado.Name = "btn_consultarsupermercado";
            this.btn_consultarsupermercado.Size = new System.Drawing.Size(141, 40);
            this.btn_consultarsupermercado.TabIndex = 9;
            this.btn_consultarsupermercado.Text = "Consultar Supermercado";
            this.btn_consultarsupermercado.UseVisualStyleBackColor = true;
            this.btn_consultarsupermercado.Click += new System.EventHandler(this.btn_consultarsupermercado_Click);
            // 
            // btn_actualizarsupermercado
            // 
            this.btn_actualizarsupermercado.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_actualizarsupermercado.BackgroundImage")));
            this.btn_actualizarsupermercado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_actualizarsupermercado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_actualizarsupermercado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_actualizarsupermercado.Location = new System.Drawing.Point(131, 155);
            this.btn_actualizarsupermercado.Name = "btn_actualizarsupermercado";
            this.btn_actualizarsupermercado.Size = new System.Drawing.Size(141, 40);
            this.btn_actualizarsupermercado.TabIndex = 10;
            this.btn_actualizarsupermercado.Text = "Actualizar Supermercado";
            this.btn_actualizarsupermercado.UseVisualStyleBackColor = true;
            this.btn_actualizarsupermercado.Click += new System.EventHandler(this.btn_actualizarsupermercado_Click);
            // 
            // btn_actualizarsede
            // 
            this.btn_actualizarsede.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_actualizarsede.BackgroundImage")));
            this.btn_actualizarsede.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_actualizarsede.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_actualizarsede.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_actualizarsede.Location = new System.Drawing.Point(305, 155);
            this.btn_actualizarsede.Name = "btn_actualizarsede";
            this.btn_actualizarsede.Size = new System.Drawing.Size(141, 40);
            this.btn_actualizarsede.TabIndex = 11;
            this.btn_actualizarsede.Text = "Actualizar Sede";
            this.btn_actualizarsede.UseVisualStyleBackColor = true;
            this.btn_actualizarsede.Click += new System.EventHandler(this.btn_actualizarsede_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Wide Latin", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(489, 33);
            this.label1.TabIndex = 12;
            this.label1.Text = "Menú Supermercado";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Supermercado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(564, 262);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_actualizarsede);
            this.Controls.Add(this.btn_actualizarsupermercado);
            this.Controls.Add(this.btn_consultarsupermercado);
            this.Controls.Add(this.btn_agregarnuevasede);
            this.Controls.Add(this.btn_agregarsupermercado);
            this.Controls.Add(this.btncancelar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Supermercado";
            this.Text = "Supermercado";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncancelar;
        private System.Windows.Forms.Button btn_agregarsupermercado;
        private System.Windows.Forms.Button btn_agregarnuevasede;
        private System.Windows.Forms.Button btn_consultarsupermercado;
        private System.Windows.Forms.Button btn_actualizarsupermercado;
        private System.Windows.Forms.Button btn_actualizarsede;
        private System.Windows.Forms.Label label1;
    }
}