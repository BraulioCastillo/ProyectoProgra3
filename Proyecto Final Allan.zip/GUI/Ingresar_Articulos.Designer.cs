﻿namespace ProyectoFinal
{
    partial class Ingresar_Articulos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ingresar_Articulos));
            this.gbx_insertarProducto = new System.Windows.Forms.GroupBox();
            this.btn_cargar_img = new System.Windows.Forms.Button();
            this.pb_imagen = new System.Windows.Forms.PictureBox();
            this.btn_ingresar = new System.Windows.Forms.Button();
            this.txb_stock_insertar = new System.Windows.Forms.TextBox();
            this.txb_precio_insertar = new System.Windows.Forms.TextBox();
            this.txb_detalles_insertar = new System.Windows.Forms.TextBox();
            this.txb_ID_insertar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btncancelar = new System.Windows.Forms.Button();
            this.gbx_insertarProducto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_imagen)).BeginInit();
            this.SuspendLayout();
            // 
            // gbx_insertarProducto
            // 
            this.gbx_insertarProducto.Controls.Add(this.btn_cargar_img);
            this.gbx_insertarProducto.Controls.Add(this.pb_imagen);
            this.gbx_insertarProducto.Controls.Add(this.btn_ingresar);
            this.gbx_insertarProducto.Controls.Add(this.txb_stock_insertar);
            this.gbx_insertarProducto.Controls.Add(this.txb_precio_insertar);
            this.gbx_insertarProducto.Controls.Add(this.txb_detalles_insertar);
            this.gbx_insertarProducto.Controls.Add(this.txb_ID_insertar);
            this.gbx_insertarProducto.Controls.Add(this.label4);
            this.gbx_insertarProducto.Controls.Add(this.label3);
            this.gbx_insertarProducto.Controls.Add(this.label2);
            this.gbx_insertarProducto.Controls.Add(this.label1);
            this.gbx_insertarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx_insertarProducto.Location = new System.Drawing.Point(13, 89);
            this.gbx_insertarProducto.Margin = new System.Windows.Forms.Padding(4);
            this.gbx_insertarProducto.Name = "gbx_insertarProducto";
            this.gbx_insertarProducto.Padding = new System.Windows.Forms.Padding(4);
            this.gbx_insertarProducto.Size = new System.Drawing.Size(740, 454);
            this.gbx_insertarProducto.TabIndex = 2;
            this.gbx_insertarProducto.TabStop = false;
            // 
            // btn_cargar_img
            // 
            this.btn_cargar_img.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cargar_img.BackgroundImage")));
            this.btn_cargar_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cargar_img.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cargar_img.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_cargar_img.Location = new System.Drawing.Point(47, 242);
            this.btn_cargar_img.Name = "btn_cargar_img";
            this.btn_cargar_img.Size = new System.Drawing.Size(104, 57);
            this.btn_cargar_img.TabIndex = 10;
            this.btn_cargar_img.Text = "Cargar Imagen";
            this.btn_cargar_img.UseVisualStyleBackColor = true;
            // 
            // pb_imagen
            // 
            this.pb_imagen.Location = new System.Drawing.Point(157, 242);
            this.pb_imagen.Name = "pb_imagen";
            this.pb_imagen.Size = new System.Drawing.Size(551, 133);
            this.pb_imagen.TabIndex = 9;
            this.pb_imagen.TabStop = false;
            // 
            // btn_ingresar
            // 
            this.btn_ingresar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ingresar.BackgroundImage")));
            this.btn_ingresar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ingresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ingresar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ingresar.Location = new System.Drawing.Point(272, 401);
            this.btn_ingresar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ingresar.Name = "btn_ingresar";
            this.btn_ingresar.Size = new System.Drawing.Size(312, 45);
            this.btn_ingresar.TabIndex = 8;
            this.btn_ingresar.Text = "Ingresar Articulo";
            this.btn_ingresar.UseVisualStyleBackColor = true;
            // 
            // txb_stock_insertar
            // 
            this.txb_stock_insertar.Location = new System.Drawing.Point(157, 104);
            this.txb_stock_insertar.Margin = new System.Windows.Forms.Padding(4);
            this.txb_stock_insertar.Name = "txb_stock_insertar";
            this.txb_stock_insertar.Size = new System.Drawing.Size(148, 22);
            this.txb_stock_insertar.TabIndex = 7;
            // 
            // txb_precio_insertar
            // 
            this.txb_precio_insertar.Location = new System.Drawing.Point(157, 73);
            this.txb_precio_insertar.Margin = new System.Windows.Forms.Padding(4);
            this.txb_precio_insertar.Name = "txb_precio_insertar";
            this.txb_precio_insertar.Size = new System.Drawing.Size(148, 22);
            this.txb_precio_insertar.TabIndex = 6;
            // 
            // txb_detalles_insertar
            // 
            this.txb_detalles_insertar.Location = new System.Drawing.Point(157, 147);
            this.txb_detalles_insertar.Margin = new System.Windows.Forms.Padding(4);
            this.txb_detalles_insertar.Multiline = true;
            this.txb_detalles_insertar.Name = "txb_detalles_insertar";
            this.txb_detalles_insertar.Size = new System.Drawing.Size(551, 85);
            this.txb_detalles_insertar.TabIndex = 5;
            // 
            // txb_ID_insertar
            // 
            this.txb_ID_insertar.Location = new System.Drawing.Point(157, 40);
            this.txb_ID_insertar.Margin = new System.Windows.Forms.Padding(4);
            this.txb_ID_insertar.Name = "txb_ID_insertar";
            this.txb_ID_insertar.Size = new System.Drawing.Size(148, 22);
            this.txb_ID_insertar.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(92, 104);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Stock:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 73);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Precio:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(81, 150);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Detalle:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID Articulo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Wide Latin", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(96, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(587, 33);
            this.label5.TabIndex = 20;
            this.label5.Text = "Insertar Nuevo Producto";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btncancelar
            // 
            this.btncancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncancelar.BackgroundImage")));
            this.btncancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancelar.ForeColor = System.Drawing.Color.White;
            this.btncancelar.Location = new System.Drawing.Point(664, 585);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(100, 40);
            this.btncancelar.TabIndex = 21;
            this.btncancelar.Text = "Salir";
            this.btncancelar.UseVisualStyleBackColor = true;
            this.btncancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // Ingresar_Articulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 626);
            this.Controls.Add(this.btncancelar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gbx_insertarProducto);
            this.Name = "Ingresar_Articulos";
            this.Text = "Ingresar Articulos";
            this.gbx_insertarProducto.ResumeLayout(false);
            this.gbx_insertarProducto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_imagen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbx_insertarProducto;
        private System.Windows.Forms.Button btn_cargar_img;
        private System.Windows.Forms.PictureBox pb_imagen;
        private System.Windows.Forms.Button btn_ingresar;
        private System.Windows.Forms.TextBox txb_stock_insertar;
        private System.Windows.Forms.TextBox txb_precio_insertar;
        private System.Windows.Forms.TextBox txb_detalles_insertar;
        private System.Windows.Forms.TextBox txb_ID_insertar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btncancelar;
    }
}